let korisnici = [
    {
        email : "korisnik1@raf.rs",
        pass : "1234",
        name : "korisnik1",
        admin: true
    },
    {
        email : "korisnik2@raf.rs",
        pass : "1234",
        name : "drkorisnik2ugi",
        admin: true

    },
    {
        email : "korisnik3@raf.rs",
        pass : "1234",
        name : "korisnik3",
        admin: false
    },
    {
        email : "korisnik4@raf.rs",
        pass : "1234",
        name : "korisnik4",
        admin: false
    }
];

let korisnik = {
    email: '',
    name: '',
    admin: false
};

let proizvodi = [
    {
        ime: 'IBANEZ JEM7VP STEVE VAI SIGNATURE IN WHITE ',
        img: './Slicice/gitara.jpg',
        gitara: 'Ibanez',
        cena: 1700
    },
    {
        ime: 'Fender Trzalice',
        img: './Slicice/trzalica2.jpg',
        gitara: 'Fender',
        cena: 2
    },
    {
        ime: 'Dunlop Zice za gitaru',
        img: './Slicice/zice.jpg',
        gitara: 'DunlopPro',
        cena: 15
    }
   
];


let korpa = [
    
];