
/*
function registracija(){
    let email = document.getElementById('exampleInputEmail1').value;
    let pass = document.getElementById('exampleInputPassword1').value;
    let name = document.getElementById('ime').value;

    let pro = true;

    korisnici.map(d => {
        if(d.email === email){
            pro = false;
        }
    });
    if(pro){
        localStorage.setItem('noviNiz',[email,pass,name,false]);
        window.location.href = 'file:///C:/Users/Srdjo/Desktop/DomaciZaSkript/loginProzor.html';
        
    }else{
        alert('korisnik sa ovim imejlom vec postoji probajte sa nekim drugim');
    }

}*/