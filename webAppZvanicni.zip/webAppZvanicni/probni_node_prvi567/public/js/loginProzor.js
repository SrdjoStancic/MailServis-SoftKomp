
/*function provera() {
    let inputEmail = document.getElementById('exampleInputEmail1').value;
    let inputPass = document.getElementById('exampleInputPassword1').value;
    let pro = true;
    korisnici.map(item => {
        if (inputEmail === item.email && inputPass === item.pass) {
            pro = false;

        }
    });

    let dijelovi = localStorage.getItem('niz') + ',' + localStorage.getItem('noviNiz');
    
    dijelovi = dijelovi.split(',');
    
    for(let i=0;i<dijelovi.length;i++){
        
        if(dijelovi[i] === inputEmail && dijelovi[i+1] === inputPass){
            pro = false;
        }

    }

    


    localStorage.setItem('niz',dijelovi);




    if (pro) {
        alert('Nesto ste pogrsili');
    } else {
        window.location.href = 'file:///C:/Users/Srdjo/probni_node_prvi/public/home.html';
    }

    

}*/
