const members=[
    {
        email: 'srdjo@gmail.com',
        password: '1234'
    }



];

module.exports= members;